import java.util.Scanner;

public class Exercise1Final {
	
	public static int letterToNumber(String[] hellArray, String string1) {
		boolean flag = false; 
		int thesi = 0; 
		int f = 0; 
		while (f < hellArray.length && flag == false) {
			if (hellArray[f].equals(string1)) {
				flag = true;
				thesi = f + 1;
			}
			f = f + 1;
		}
		System.out.println(thesi);
		return thesi; 
	}
	
	public static boolean findString (String[] hellArray, String string1) {
		boolean flag = false; 
		int thesi = 0; 
		int f = 0; 
		
		while (f < hellArray.length && flag == false) {
			if (hellArray[f].equals(string1)) {
				flag = true;
				thesi = f + 1;
			}
			f = f + 1;
		}
		
		if (flag == true) {
			//System.out.print("vrethike sti thesi ");
			//System.out.println(thesi);
		} else {
			//System.out.println("den vrethike!");
		}
		
		return flag; 
	}

	public static void main(String[] args) {
		
		// dhmiourgia pinaka ellhnikhs arithmisis pou periexei tous arithmous apo 1 - 1000
		String [] hellenic = new String[1000]; //pinakas pou exei apothikeumenous tous arithmous 0 - 1000 sto ellhniko susthma arithmhshs
		int[] psDipsif = new int[2]; // psifia enos dipsifiou arithmou
		int[] psTripsif = new int[3]; //psifia enos 
		int plithos = 0;
		
		for (int k = 0; k < hellenic.length; k++) {
			hellenic[k] = " ";
		}
		for (int i = 0; i < hellenic.length; i++) {
			if (i + 1 == 1) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 2) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 3) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 4) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 5) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 6) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 7) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 8) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 9) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 10) {
				hellenic[i] = "�\'"; 
			} else if (i + 1 == 20) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 30) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 40) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 50) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 60) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 70) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 80) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 90) {
				hellenic[i] = "Q\'";
			} else if (i + 1 == 100) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 200) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 300) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 400) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 500) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 600) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 700) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 800) {
				hellenic[i] = "�\'";
			} else if (i + 1 == 900) {
				hellenic[i] = "W\'";
			} else if (i + 1 == 1000) {
				hellenic[i] = ",A\'";
			} else {
				
				if (i + 1 >= 100 && i + 1 < 1000) { //tripsifios
					plithos = 0;
					int modAr = (i + 1) % 10;
					plithos = 2;
					int divAr = (i + 1) / 10; 
					psTripsif[2] = modAr;
					
					while (divAr != 0 && plithos >= 0) {
						modAr = divAr % 10;
						plithos = plithos - 1;
						psTripsif[plithos] = modAr;
						divAr = divAr / 10; 
					}
					
					for (int d = 0; d < psTripsif.length; d++) {
						//System.out.println("psTripsif " + psTripsif[d]);
					}
					
					if (psTripsif[2] == 0 && psTripsif[1] != 0) {
						
						hellenic[i] = hellenic[100*psTripsif[0] - 1] + hellenic[10*psTripsif[1] - 1];
						
					} else if (psTripsif[1] == 0 && psTripsif[2] != 0) {
						
						hellenic[i] = hellenic[100*psTripsif[0] - 1] + hellenic[1*psTripsif[2] - 1]; 
						
					} else if (psTripsif[1] != 0 && psTripsif[2] != 0) {
						
						hellenic[i] = hellenic[100*psTripsif[0] - 1] + hellenic[10*psTripsif[1] - 1] + hellenic[1*psTripsif[2] - 1]; 
						
					}
					
				} else if (i + 1 > 10 && i + 1 < 100) {
					plithos = 2;
					int modAr = (i + 1) % 10;
					int divAr = (i + 1) / 10; 
					psDipsif[1] = modAr;
					modAr = divAr % 10;
					divAr = divAr / 10;
					psDipsif[0] = modAr;
					for (int d = 0; d < psDipsif.length; d++) {
						//System.out.println("psDipsif " + psDipsif[d]);
					}
					hellenic[i] = hellenic[10*psDipsif[0] - 1];	
					hellenic[i] = hellenic[i] + hellenic[1*psDipsif[1] - 1];
				} 
					
				//System.out.println("hellenic " + hellenic[i]);
			}	
		} // for tou hellenic ekswterikh
		
		//dhmiourgia susthmatos latinikhs arithmhshs
		String[] latin = new String[1000];		//pinakas pou exei apothikeumenous tous arithmous 0 - 1000 sto latiniko susthma arithmhshs
		int[] latinValue = new int[1000];
		for (int o = 0; o < latin.length; o++) {
			latin[o] = " "; //initializing 
		}
		for (int y = 0; y < latin.length; y++) {
			if (y + 1 == 1) {
				latin[y] = "I";
				latinValue[y] = 1;
			} else if (y + 1 == 5) {
				latin[y] = "V";
				latinValue[y] = 5;
			} else if (y + 1 == 10) {
				latin[y] = "X";
				latinValue[y] = 10;
			} else if (y + 1 == 50) {
				latin[y] = "L";
				latinValue[y] = 50;
			} else if (y + 1 == 100) {
				latin[y] = "C";
				latinValue[y] = 100;
			} else if (y + 1 == 500) {
				latin[y] = "D";
				latinValue[y] = 500;
			} else if (y + 1 == 1000) {
				latin[y] = "M";
				latinValue[y] = 1000;
			} else {
					if ((latin[y - 1].equals("I") || latin[y-1].equals("X") || latin[y-1].equals("C")) && latin[y].equals(" ")) {
						for (int m = 2; m <= 3; m++) {
							latin[latinValue[y-1] * m - 1] = latin[y-1]; // arxikopoiw 
							
							for (int a = 0; a < m - 1; a++) {		
								latin[latinValue[y-1] * m - 1] = latin[y-1] + latin[latinValue[y-1] * m - 1];
							}
							//System.out.println("latin");
							//System.out.println(latinValue[y-1] * m - 1);
							//System.out.println(latin[latinValue[y-1] * m - 1]);
							 
							}
					} //else if (y == 3 || y == 8 || y == 39 || y == 90 || y == 399 || y == 899) {
						
					}
				}				
		


		
		// eisodos arithmou - arxh diadikasias
		Scanner scanner = new Scanner(System.in);
		System.out.print("Please insert the arithmetic expression you want to be calculated in this way: \"number\" \"operator\" \"number\" without these characters \" ");
		String ekf = scanner.nextLine();
		//System.out.println("The arithmetic expression was: " + ekf);
		String[] telestes = new String[4];
		String str1 = "+", str2 = "*", str3 = "/";
		telestes[0] = str1;
		telestes[1] = "-";
		telestes[2] = str2;
		telestes[3] = str3;
		
		while (ekf.length() > 0) {
			
			String[] parts = ekf.split(" ", 3);
			String part1 = parts[0]; 
			String part2 = parts[1]; 
			String part3 = parts[2];	
			String[] numbers = new String[2];// periexei tous telikous 2 arithmous 
			
			for (int j = 0; j < numbers.length; j++) {
				numbers[j] = parts[j]; //initializing
			}
			
	
			int thesiTelesti = 0;
			for (int i = 0; i < parts.length; i++) {
				for (int k = 0; k < telestes.length; k++) {
					if (parts[i].equals(telestes[k])) {
						thesiTelesti = i; //thesi telesti stin parts
											
					}
				}	
			}
			
			for (int u = 0; u < numbers.length; u++) {
				if (numbers[u].equals(parts[thesiTelesti])) {
					numbers[u] = parts[thesiTelesti + 1];
				}
			}
			
			for (int g = 0; g < numbers.length; g++) {
				System.out.println(numbers[g]);
			}
			
			for (int r = 0; r < numbers.length; r++) {
				boolean flag = findString(hellenic, numbers[r]);
				if (flag == true) { 
					letterToNumber(hellenic, numbers[r]);
				}	
			}
			System.out.print("Please insert the arithmetic expression you want to be calculated in this way:\"number\" \"operator\" \"number\" without these characters \" ");
			ekf = scanner.nextLine();
		}

	} // end of main
} // end of class


